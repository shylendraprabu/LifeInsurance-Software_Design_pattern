import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import '../styles/Home.css';
import Header from './Header';
import Footer from './Footer';
import Slideshow from './Slideshow';
import axios from 'axios';

const Home = () => {
  const [policies, setPolicies] = useState([]);

  // Get JWT token from localStorage
  const token = localStorage.getItem('jwtToken');

  // Axios instance with JWT token in headers
  const axiosInstance = axios.create({
    baseURL: 'http://localhost:8080/api',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  useEffect(() => {
    // Fetch policies from backend with JWT token
    axiosInstance.get('/policies')
      .then(response => {
        setPolicies(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the policies!', error);
      });
  }, []);

  return (
    <main>
      <Header />
      <section id="home" className="hero-section">
        <Slideshow />
        <div className="hero-content">
          <h2>Welcome to Our Life Ensure</h2>
          <p>Secure your future with our comprehensive life insurance plans.</p>
        </div>
      </section>
      <section id="services" className="services-section">
        <h2>Our Policies</h2>
        <div className="cards-container">
          {policies.map((policy) => (
            <Link key={policy.id} to={`/policy/${policy.id}`} className="card">
              <div className="card-image">
                <img src={policy.imageUrl} alt={policy.name} />
              </div>
              <div className="card-content">
                <h3>{policy.name}</h3>
                <p>{policy.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
      <Footer />
    </main>
  );
};

export default Home;
