import React, { useState, useEffect } from 'react';
import Layout from './Layout';
import axios from 'axios';
import '../styles/PolicyManagement.css';

const PolicyManagement = () => {
  const [policies, setPolicies] = useState([]);
  const [newPolicy, setNewPolicy] = useState({ name: '', description: '', imageUrl: '' });
  const [editingIndex, setEditingIndex] = useState(null);
  const [editPolicy, setEditPolicy] = useState({ name: '', description: '', imageUrl: '' });
  const [searchTerm, setSearchTerm] = useState('');

  // Get JWT token from localStorage
  const token = localStorage.getItem('jwtToken');

  // Axios instance with JWT token in headers
  const axiosInstance = axios.create({
    baseURL: 'http://localhost:8080/api',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  useEffect(() => {
    // Fetch policies from backend with JWT token
    axiosInstance.get('/policies')
      .then(response => {
        setPolicies(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the policies!', error);
      });
  }, []);

  const handleAddPolicy = () => {
    if (newPolicy.name.trim()) {
      axiosInstance.post('/policies', newPolicy)
        .then(response => {
          setPolicies([...policies, response.data]);
          setNewPolicy({ name: '', description: '', imageUrl: '' });
        })
        .catch(error => {
          console.error('There was an error adding the policy!', error);
        });
    }
  };

  const handleDeletePolicy = (id, index) => {
    if (window.confirm('Are you sure you want to delete this policy?')) {
      axiosInstance.delete(`/policies/${id}`)
        .then(() => {
          setPolicies(policies.filter((_, i) => i !== index));
        })
        .catch(error => {
          console.error('There was an error deleting the policy!', error);
        });
    }
  };

  const handleEditPolicy = (index) => {
    setEditingIndex(index);
    setEditPolicy(policies[index]);
  };

  const handleSaveEdit = (id, index) => {
    axiosInstance.put(`/policies/${id}`, editPolicy)
      .then(response => {
        const updatedPolicies = [...policies];
        updatedPolicies[index] = response.data;
        setPolicies(updatedPolicies);
        setEditingIndex(null);
        setEditPolicy({ name: '', description: '', imageUrl: '' });
      })
      .catch(error => {
        console.error('There was an error updating the policy!', error);
      });
  };

  const filteredPolicies = policies.filter(policy =>
    policy.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Layout>
      <div className="policy-management-container">
        <h1>Policy Management</h1>
        <div className="policy-management">
          <input 
            type="text" 
            value={newPolicy.name} 
            onChange={(e) => setNewPolicy({ ...newPolicy, name: e.target.value })} 
            placeholder="Policy Name" 
          />
          <input 
            type="text" 
            value={newPolicy.description} 
            onChange={(e) => setNewPolicy({ ...newPolicy, description: e.target.value })} 
            placeholder="Policy Description" 
          />
          <input 
            type="text" 
            value={newPolicy.imageUrl} 
            onChange={(e) => setNewPolicy({ ...newPolicy, imageUrl: e.target.value })} 
            placeholder="Image URL" 
          />
          <button onClick={handleAddPolicy}>Add Policy</button>

          <div className="search-sort">
            <input 
              type="text" 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)} 
              placeholder="Search Policies" 
            />
          </div>

          <ul>
            {filteredPolicies.map((policy, index) => (
              <li key={policy.id}>
                {editingIndex === index ? (
                  <>
                    <input 
                      type="text" 
                      value={editPolicy.name} 
                      onChange={(e) => setEditPolicy({ ...editPolicy, name: e.target.value })} 
                    />
                    <input 
                      type="text" 
                      value={editPolicy.description} 
                      onChange={(e) => setEditPolicy({ ...editPolicy, description: e.target.value })} 
                    />
                    <input 
                      type="text" 
                      value={editPolicy.imageUrl} 
                      onChange={(e) => setEditPolicy({ ...editPolicy, imageUrl: e.target.value })} 
                    />
                    <button onClick={() => handleSaveEdit(policy.id, index)}>Save</button>
                    <button onClick={() => setEditingIndex(null)}>Cancel</button>
                  </>
                ) : (
                  <>
                    <h3>{policy.name}</h3>
                    <p>{policy.description}</p>
                    <img src={policy.imageUrl} alt={policy.name} style={{ width: '100px', height: '100px' }} />
                    <div>
                      <button onClick={() => handleEditPolicy(index)}>Edit</button>
                      <button onClick={() => handleDeletePolicy(policy.id, index)}>Delete</button>
                    </div>
                  </>
                )}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Layout>
  );
};

export default PolicyManagement;
