import React, { useState, useEffect } from 'react';
import Layout from './Layout';
import axios from 'axios';
import "../styles/PaymentsBilling.css";


const PaymentsBilling = () => {
  const [payments, setPayments] = useState([]);
  const [newPayment, setNewPayment] = useState('');
  const [editingIndex, setEditingIndex] = useState(null);
  const [editPayment, setEditPayment] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Retrieve the JWT token from local storage
  const token = localStorage.getItem('jwtToken');

  useEffect(() => {
    // Fetch payments from the backend with JWT token in headers
    axios.get('http://localhost:8080/api/payments', {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    })
    .then(response => {
      setPayments(response.data);
    })
    .catch(error => {
      console.error('There was an error fetching the payments!', error);
    });
  }, [token]);

  const handleAddPayment = () => {
    if (newPayment.trim()) {
      axios.post('http://localhost:8080/api/payments', { name: newPayment }, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      })
      .then(response => {
        setPayments([...payments, response.data]);
        setNewPayment('');
      })
      .catch(error => {
        console.error('There was an error adding the payment!', error);
        // Display a user-friendly error message based on the response
        if (error.response) {
          alert(`Error: ${error.response.data.message || 'Failed to add payment'}`);
        } else if (error.request) {
          alert('Error: No response received from the server.');
        } else {
          alert('Error: Request setup was incorrect.');
        }
      });
    } else {
      alert('Payment details cannot be empty.');
    }
  };

  const handleDeletePayment = (id, index) => {
    if (window.confirm('Are you sure you want to delete this payment?')) {
      axios.delete(`http://localhost:8080/api/payments/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      })
      .then(() => {
        setPayments(payments.filter((_, i) => i !== index));
      })
      .catch(error => {
        console.error('There was an error deleting the payment!', error);
      });
    }
  };

  const handleEditPayment = (index) => {
    setEditingIndex(index);
    setEditPayment(payments[index].name);
  };

  const handleSaveEdit = (id, index) => {
    axios.put(`http://localhost:8080/api/payments/${id}`, { name: editPayment }, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    })
    .then(response => {
      const updatedPayments = [...payments];
      updatedPayments[index] = response.data;
      setPayments(updatedPayments);
      setEditingIndex(null);
      setEditPayment('');
    })
    .catch(error => {
      console.error('There was an error updating the payment!', error);
    });
  };

  const filteredPayments = payments.filter(payment =>
    payment.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSortPayments = () => {
    const sortedPayments = [...payments].sort((a, b) => a.name.localeCompare(b.name));
    setPayments(sortedPayments);
  };

  return (
    <Layout>
      <div className="payment-management-container">
        <h1>Payment Management</h1>
        <div className="payment-management">
          <input 
            type="text" 
            value={newPayment} 
            onChange={(e) => setNewPayment(e.target.value)} 
            placeholder="New Payment" 
          />
          <button onClick={handleAddPayment}>Add Payment</button>

          <div className="search-sort">
            <input 
              type="text" 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)} 
              placeholder="Search Payments" 
            />
            <button onClick={handleSortPayments}>Sort Payments</button>
          </div>

          <ul>
            {filteredPayments.map((payment, index) => (
              <li key={payment.id}>
                {editingIndex === index ? (
                  <>
                    <input 
                      type="text" 
                      value={editPayment} 
                      onChange={(e) => setEditPayment(e.target.value)} 
                    />
                    <button onClick={() => handleSaveEdit(payment.id, index)}>Save</button>
                    <button onClick={() => setEditingIndex(null)}>Cancel</button>
                  </>
                ) : (
                  <>
                    {payment.name}
                    <div>
                      <button onClick={() => handleEditPayment(index)}>Edit</button>
                      <button onClick={() => handleDeletePayment(payment.id, index)}>Delete</button>
                    </div>
                  </>
                )}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Layout>
  );
};

export default PaymentsBilling;
