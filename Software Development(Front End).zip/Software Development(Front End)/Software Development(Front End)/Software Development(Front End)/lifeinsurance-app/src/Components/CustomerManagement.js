import React, { useState, useEffect } from 'react';
import Layout from './Layout';
import axios from 'axios';
import '../styles/CustomerManagement.css';

const CustomerManagement = () => {
  const [customers, setCustomers] = useState([]);
  const [newCustomer, setNewCustomer] = useState('');
  const [editingIndex, setEditingIndex] = useState(null);
  const [editCustomer, setEditCustomer] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Retrieve the JWT token from local storage
  const token = localStorage.getItem('jwtToken');

  useEffect(() => {
    // Fetch customers from the backend with JWT token in headers
    axios.get('http://localhost:8080/api/policy', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
      .then(response => {
        setCustomers(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the customers!', error);
      });
  }, [token]);

  const handleAddCustomer = () => {
    if (newCustomer.trim()) {
      axios.post('http://localhost:8080/api/policy', { name: newCustomer }, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      .then(response => {
        setCustomers([...customers, response.data]);
        setNewCustomer('');
      })
      .catch(error => {
        console.error('There was an error adding the customer!', error);
  
        // Display a user-friendly error message based on the response
        if (error.response) {
          alert(`Error: ${error.response.data.message || 'Failed to add customer'}`);
        } else if (error.request) {
          alert('Error: No response received from the server.');
        } else {
          alert('Error: Request setup was incorrect.');
        }
      });
    } else {
      alert('Customer name cannot be empty.');
    }
  };

  const handleDeleteCustomer = (id, index) => {
    if (window.confirm('Are you sure you want to delete this customer?')) {
      axios.delete(`http://localhost:8080/api/policy/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
        .then(() => {
          setCustomers(customers.filter((_, i) => i !== index));
        })
        .catch(error => {
          console.error('There was an error deleting the customer!', error);
        });
    }
  };

  const handleEditCustomer = (index) => {
    setEditingIndex(index);
    setEditCustomer(customers[index].name);
  };

  const handleSaveEdit = (id, index) => {
    axios.put(`http://localhost:8080/api/policy/${id}`, { name: editCustomer }, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
      .then(response => {
        const updatedCustomers = [...customers];
        updatedCustomers[index] = response.data;
        setCustomers(updatedCustomers);
        setEditingIndex(null);
        setEditCustomer('');
      })
      .catch(error => {
        console.error('There was an error updating the customer!', error);
      });
  };

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSortCustomers = () => {
    const sortedCustomers = [...customers].sort((a, b) => a.name.localeCompare(b.name));
    setCustomers(sortedCustomers);
  };

  return (
    <Layout>
      <div className="customer-management-container">
        <h1>Customer Management</h1>
        <div className="customer-management">
          <input 
            type="text" 
            value={newCustomer} 
            onChange={(e) => setNewCustomer(e.target.value)} 
            placeholder="New Customer" 
          />
          <button onClick={handleAddCustomer}>Add Customer</button>

          <div className="search-sort">
            <input 
              type="text" 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)} 
              placeholder="Search Customers" 
            />
            <button onClick={handleSortCustomers}>Sort Customers</button>
          </div>

          <ul>
            {filteredCustomers.map((customer, index) => (
              <li key={customer.id}>
                {editingIndex === index ? (
                  <>
                    <input 
                      type="text" 
                      value={editCustomer} 
                      onChange={(e) => setEditCustomer(e.target.value)} 
                    />
                    <button onClick={() => handleSaveEdit(customer.id, index)}>Save</button>
                    <button onClick={() => setEditingIndex(null)}>Cancel</button>
                  </>
                ) : (
                  <>
                    {customer.name}
                    <div>
                      <button onClick={() => handleEditCustomer(index)}>Edit</button>
                      <button onClick={() => handleDeleteCustomer(customer.id, index)}>Delete</button>
                    </div>
                  </>
                )}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Layout>
  );
};

export default CustomerManagement;
