package com.example.lifeensure;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LifeensureApplicationTests {

	@Test
	void contextLoads() {
	}

}
