package com.example.lifeensure.Config;

public class ApplicationConfig {
    
}
