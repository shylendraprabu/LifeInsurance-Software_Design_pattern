package com.security.template.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.security.template.model.Policies;
import com.security.template.repo.PoliciesRepository;

import java.util.List;

@Service
public class PoliciesService {
    @Autowired
    private PoliciesRepository policyRepository;

    public List<Policies> getAllPolicies() {
        return policyRepository.findAll();
    }

    public Policies addPolicy(Policies policy) {
        return policyRepository.save(policy);
    }

    public Policies updatePolicy(Long id, Policies policy) {
        return policyRepository.findById(id).map(existingPolicy -> {
            existingPolicy.setName(policy.getName());
            existingPolicy.setDescription(policy.getDescription());
            existingPolicy.setImageUrl(policy.getImageUrl());
            return policyRepository.save(existingPolicy);
        }).orElseThrow(() -> new RuntimeException("Policy not found with id " + id));
    }
    
    public void deletePolicies(Long id) {
        policyRepository.deleteById(id);
    }
}
