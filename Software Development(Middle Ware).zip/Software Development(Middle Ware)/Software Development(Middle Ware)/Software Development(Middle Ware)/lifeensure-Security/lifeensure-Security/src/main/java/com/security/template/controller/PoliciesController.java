package com.security.template.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.security.template.model.Policies;
import com.security.template.service.PoliciesService;

import java.util.List;


@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3001"})
@RestController
@RequestMapping("/api/policies")
public class PoliciesController {
    @Autowired
    private PoliciesService policyService;

    @GetMapping
    public List<Policies> getAllPolicies() {
        return policyService.getAllPolicies();
    }

    @PostMapping
    public Policies addPolicy(@RequestBody Policies policy) {
        return policyService.addPolicy(policy);
    }

    @PutMapping("/{id}")
    public Policies updatePolicy(@PathVariable Long id, @RequestBody Policies policy) {
        return policyService.updatePolicy(id, policy);
    }

    @DeleteMapping("/{id}")
    public void deletePolicy(@PathVariable Long id) {
        policyService.deletePolicies(id);
    }
}
